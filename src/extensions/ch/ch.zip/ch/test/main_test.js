describe("show notifications", function() {
    it("must pop up", function() {
        expect(helloWorld()).toEqual("Hello world!");
    });
    it("must show", function() {
        expect(helloWorld()).toEqual("Hello world!");
    });
});

describe("toolbar button", function() {
    it("must toggle the icon", function() {
        expect(helloWorld()).toEqual("Hello world!");
    });
});

describe("HTTP interception", function() {
    it("matches regular expressions", function() {
        expect(helloWorld()).toEqual("Hello world!");
    });
    it("blocks matched requests", function() {
        expect(helloWorld()).toEqual("Hello world!");
    });

});

